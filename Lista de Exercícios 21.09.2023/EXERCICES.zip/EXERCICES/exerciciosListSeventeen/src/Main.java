import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner exe = new Scanner(System.in);

        // Solicitar os valores de a e b
        System.out.println("Informe o valor de a: ");
        int a = exe.nextInt();

        System.out.println("Informe o valor de b: ");
        int b = exe.nextInt();


        if (a % b == 0 || b % a == 0) {
            System.out.println("São múltiplos");
        } else {
            System.out.println("Não são múltiplos");
        }

    }
}